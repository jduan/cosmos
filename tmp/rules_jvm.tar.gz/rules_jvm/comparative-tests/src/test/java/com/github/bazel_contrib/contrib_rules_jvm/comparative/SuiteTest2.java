package com.github.bazel_contrib.contrib_rules_jvm.comparative;

import org.junit.jupiter.api.Test;

public class SuiteTest2 {

  @Test
  void doSomethingElse() {
    // Also Empty
  }
}
