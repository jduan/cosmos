package com.example.gazelle;

import org.junit.jupiter.api.Test;

public class ExampleTest {
  @Test
  public void passes() {}
}
