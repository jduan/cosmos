package com.example.test;

public enum Enum1 {
    Enum1Value1("A"), // Comment
    Enum1Value2("B"), // Comment
    Enum1Value3("C"); // Comment
}
