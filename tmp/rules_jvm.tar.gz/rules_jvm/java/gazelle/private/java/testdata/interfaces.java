package com.example.test;

// This is not a valid Java file.
// It serves to collect examples of interface definitions to ensure
// the simplistic parser knows to extract them.

public interface Interface1 {}

public interface Interface2<T> {}
