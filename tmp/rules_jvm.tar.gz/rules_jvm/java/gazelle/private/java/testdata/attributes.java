package com.example.test;

// This is not a valid Java file.
// It serves to collect examples of class definitions to ensure
// the simplistic parser knows to extract them.

public class Class1 {
    public static final String Attribute1 = "TLS Handshake Attempts";
}
