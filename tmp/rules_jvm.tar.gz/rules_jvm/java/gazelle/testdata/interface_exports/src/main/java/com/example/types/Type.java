package com.example.types;

public class Type {
  public String stringify() {
    return "I am Type";
  }
}
