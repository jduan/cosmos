package com.example.iface;

import com.example.types.Type;

public interface Interface {
  public Type get();
}
