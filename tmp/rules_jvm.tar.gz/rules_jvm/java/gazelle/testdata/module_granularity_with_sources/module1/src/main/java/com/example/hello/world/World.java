package com.example.hello.world;

public class World {

    public String name;

    public World() {
        name = "World";
    }
}
