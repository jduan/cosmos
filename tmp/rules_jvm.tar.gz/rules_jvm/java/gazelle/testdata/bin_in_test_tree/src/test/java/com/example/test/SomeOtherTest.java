package com.example.test;

import org.junit.Test;

public class SomeOtherTest {
  @Test
  public void testPasses() {}
}
