package com.example.package1;

public class ClassWithInnerClass {
    public static class InnerClass {
        public String getMessage() {
            return "Woo!";
        }
    }
}
