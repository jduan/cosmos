package com.example;

import org.junit.Test;

public class FooTest {
  @Test
  public void passes() {}
}
