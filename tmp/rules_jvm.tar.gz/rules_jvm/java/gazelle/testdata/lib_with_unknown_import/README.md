# Unknown import

The extension exits with 1 when it finds a unknown import.
