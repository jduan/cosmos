package com.example.annotation;

public @interface FlakyTest {}
