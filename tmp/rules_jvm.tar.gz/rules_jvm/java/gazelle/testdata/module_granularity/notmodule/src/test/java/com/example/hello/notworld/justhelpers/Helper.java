package com.example.hello.notworld.justhelpers;

public class Helper {
  public String toUpperCase(String str) {
    return str.toUpperCase();
  }
}
