package com.example.hello.notworld;

public class NotWorld {
  public static final String NOT_WORLD = "Not World!";
}
