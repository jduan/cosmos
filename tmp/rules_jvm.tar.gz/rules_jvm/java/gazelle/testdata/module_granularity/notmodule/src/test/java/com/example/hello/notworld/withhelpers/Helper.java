package com.example.hello.hello.notworld.withhelpers;

public class Helper {
  public String toUpperCase(String str) {
    return str.toUpperCase();
  }
}
