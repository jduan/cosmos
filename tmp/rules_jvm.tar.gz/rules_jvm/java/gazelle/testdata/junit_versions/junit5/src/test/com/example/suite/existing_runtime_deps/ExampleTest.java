package com.example.suite.existing_runtime_deps;

import org.junit.jupiter.api.Test;

public class ExampleTest {
  @Test
  public void passes() {}
}
