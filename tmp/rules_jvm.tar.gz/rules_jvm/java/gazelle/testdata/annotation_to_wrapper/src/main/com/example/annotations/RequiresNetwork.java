package com.example.annotations;

public @interface RequiresNetwork {}
