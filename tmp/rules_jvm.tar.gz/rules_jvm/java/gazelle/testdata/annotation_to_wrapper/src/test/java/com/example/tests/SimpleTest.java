package com.example.tests;

import org.junit.jupiter.api.Test;

public class SimpleTest {
  @Test
  public void passes() {}
}
