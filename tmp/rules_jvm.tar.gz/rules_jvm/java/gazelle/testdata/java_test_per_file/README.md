Copied from
[bazelbuild/examples/java-maven](https://github.com/bazelbuild/examples/tree/b29794fb55f6714442dd86946c77f8908321a430/java-maven).
