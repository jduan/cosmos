package com.example.hello;

public class Hello {
    public static void sayHi() {
        System.out.println("Hi!");
    }
}
