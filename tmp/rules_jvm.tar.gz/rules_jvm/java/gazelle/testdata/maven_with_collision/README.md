# Maven with collision

Make sure the java extension does fail on colliding packages in maven.

Note that the maven_install.json file is manually crafted/invalid in order to simulate a collision on the `com.google.common.primitives` import.