// Note: the package name is not the same as the directory name for a reason.
// See this package's `BUILD.bazel` file for more information
package custom.github.bazel_contrib.contrib_rules_jvm;

import org.junit.jupiter.api.Test;

public class CustomPackageNameTest {

  @Test
  void shouldBeAbleToBeRun() {
    // This test does nothing
  }
}
