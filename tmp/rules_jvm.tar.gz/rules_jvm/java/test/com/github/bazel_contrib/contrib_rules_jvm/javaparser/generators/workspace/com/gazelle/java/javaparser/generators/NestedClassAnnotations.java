package workspace.com.gazelle.java.javaparser.generators;

import com.example.FlakyTest;

public interface NestedClassAnnotations {
    @FlakyTest
    public static class Inner {}
}
