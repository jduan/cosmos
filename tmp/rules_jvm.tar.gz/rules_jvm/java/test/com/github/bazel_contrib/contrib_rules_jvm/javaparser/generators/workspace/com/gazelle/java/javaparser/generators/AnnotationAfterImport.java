package workspace.com.gazelle.java.javaparser.generators;

import com.example.FlakyTest;

@FlakyTest
public class AnnotationAfterImport {

}
