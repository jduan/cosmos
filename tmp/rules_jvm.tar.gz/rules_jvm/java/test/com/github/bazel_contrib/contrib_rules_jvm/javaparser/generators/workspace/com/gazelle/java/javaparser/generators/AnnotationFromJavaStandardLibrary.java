package workspace.com.gazelle.java.javaparser.generators;

@Deprecated
public class AnnotationFromJavaStandardLibrary {

}
