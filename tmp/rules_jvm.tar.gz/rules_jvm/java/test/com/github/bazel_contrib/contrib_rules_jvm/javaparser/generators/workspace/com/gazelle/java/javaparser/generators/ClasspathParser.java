package workspace.com.gazelle.java.javaparser.generators;

public class ClasspathParser {}
